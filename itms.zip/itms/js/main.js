function myDataLoad() {
  $('.count').counterUp({
    delay: 10,
    time: 3000
  });
}
myBtn = document.getElementById('myBtn');


window.onscroll = function () {
  scrollFunction()
};

function scrollFunction() {
  if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
    myBtn.style.display = 'block';


  } else {
    myBtn.style.display = 'none';
  }
}

function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}


$(window).scroll(function () {
  if ($(window).scrollTop() > 60) {
    $('.my-navbar').addClass('navbar-scroll');
  } else {
    $('.my-navbar').removeClass('navbar-scroll');
  }
});



//Owl Carousel

$('.owl-carousel').owlCarousel({
  loop: true,
  margin: 25,
  responsiveClass: true,
  responsive: {
    0: {
      items: 1,
      nav: true
    },
    480: {
      items: 2,
      nav: true
    },
    768: {
      items: 3,
      nav: true
    },
    1000: {
      items: 4,
      nav: true
    }
  }
})